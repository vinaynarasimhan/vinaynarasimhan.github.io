### Contributing to the OpenPBS Open Source Project

We're so happy that you want to contribute to OpenPBS!

Please see the Contributor's Portal for details, guidelines, and how-to tutorials.  Start at **[Becoming a Contributor to OpenPBS](https://pbspro.atlassian.net/wiki/spaces/DG/pages/20414474/Becoming+a+Contributor+to+PBS+Pro)**.

Note: In May 2020, OpenPBS became the new name for the PBS Professional Open Source Project.  (PBS Professional will be used to refer to the commercial version; OpenPBS to the Open Source version -- same code, easier naming.)  As there are many parts to the project, it will take several weeks to change the name in all places, so you will continue to see references to PBS Pro (as in the above) -- stay tuned. 
